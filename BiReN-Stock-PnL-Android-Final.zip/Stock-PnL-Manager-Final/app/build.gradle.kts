plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.biren.stockpnl"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.biren.stockpnl"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
