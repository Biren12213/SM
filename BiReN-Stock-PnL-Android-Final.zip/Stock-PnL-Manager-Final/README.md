# BiReN — Stock P&L & Budget Manager

Final GitHub-ready Android project using the approved **BiReN Taurus green-and-gold logo**.

## Core features
- Buy / Sell stock entries
- FIFO realized P&L calculation
- Charges included in realized P&L
- 3 editable budget categories and percentages
- Percentage total validation (100%)
- Automatic profit allocation by current percentages
- Budget IN and OUT entries
- Cumulative remaining balances / carry-forward
- Edit and delete for trades and budget entries
- Built-in calculator for amount fields
- Home, Trades, Budget, Reports, Settings
- Local offline data storage
- GitHub Actions debug APK build

## Open in Android Studio
Open the project root. Android Studio can sync the Gradle project and run it on an Android device/emulator.

## GitHub
Push the repository to GitHub. The included workflow builds a debug APK and uploads it as a workflow artifact.

## Build from terminal
Run:

    ./gradlew assembleDebug

The first run downloads Gradle 8.11 if it is not already cached.

APK output:

    app/build/outputs/apk/debug/app-debug.apk

## Data
This lightweight release stores its local ledger in SharedPreferences JSON so there are no extra database plugins to configure. The source is structured so a Room migration can be added later.
